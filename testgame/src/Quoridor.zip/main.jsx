import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './Quoridor.css'
import App from './Quoridor.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
